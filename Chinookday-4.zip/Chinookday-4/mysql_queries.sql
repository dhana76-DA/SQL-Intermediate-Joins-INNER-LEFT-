SELECT 
    o.order_id,
    c.first_name,
    c.last_name,
    p.product_name,
    cat.category_name,
    o.order_date
FROM orders o
INNER JOIN customers c ON o.customer_id = c.customer_id
INNER JOIN products p ON o.product_id = p.product_id
INNER JOIN categories cat ON p.category_id = cat.category_id;

SELECT 
    i.InvoiceId, 
    i.InvoiceDate, 
    c.FirstName, 
    c.LastName, 
    c.Email
FROM invoice i
INNER JOIN customer c 
    ON i.CustomerId = c.CustomerId;
    
SELECT 
    c.CustomerId,
    c.FirstName,
    c.LastName,
    c.Email
FROM Customer c
LEFT JOIN Invoice i
    ON c.CustomerId = i.CustomerId
WHERE i.InvoiceId IS NULL;

SELECT
    t.TrackId AS SKU,
    t.Name AS ProductName,
    SUM(il.UnitPrice * il.Quantity) AS TotalRevenue
FROM InvoiceLine il
INNER JOIN Track t
    ON il.TrackId = t.TrackId
GROUP BY
    t.TrackId,
    t.Name
ORDER BY
    TotalRevenue DESC;
    
SELECT
    t.TrackId,
    t.Name,
    SUM(il.UnitPrice * il.Quantity) AS TotalRevenue
FROM InvoiceLine il
INNER JOIN Track t
    ON il.TrackId = t.TrackId
GROUP BY t.TrackId, t.Name
HAVING TotalRevenue > 2
ORDER BY TotalRevenue DESC;

SELECT
    g.GenreId,
    g.Name AS CategoryName,
    SUM(il.UnitPrice * il.Quantity) AS TotalRevenue
FROM Genre g
INNER JOIN Track t
    ON g.GenreId = t.GenreId
INNER JOIN InvoiceLine il
    ON t.TrackId = il.TrackId
GROUP BY
    g.GenreId,
    g.Name
ORDER BY
    TotalRevenue DESC;
    
SELECT c.FirstName, c.LastName, SUM(il.UnitPrice * il.Quantity) AS TotalSales
FROM Invoice i
INNER JOIN InvoiceLine il ON i.InvoiceId = il.InvoiceId
INNER JOIN Customer c ON i.CustomerId = c.CustomerId
WHERE i.BillingCountry = 'USA'
  AND i.InvoiceDate BETWEEN '2010-01-01' AND '2010-12-31'
GROUP BY c.CustomerId, c.FirstName, c.LastName
ORDER BY TotalSales DESC;

SELECT
    i.BillingCountry AS Country,
    SUM(il.UnitPrice * il.Quantity) AS TotalSales
FROM Invoice i
INNER JOIN InvoiceLine il
    ON i.InvoiceId = il.InvoiceId
WHERE i.BillingCountry = 'USA'
  AND i.InvoiceDate BETWEEN '2021-01-01' AND '2021-12-31'
GROUP BY i.BillingCountry;

SELECT
    g.Name AS Genre,
    SUM(il.UnitPrice * il.Quantity) AS GenreSales
FROM Invoice i
INNER JOIN InvoiceLine il
    ON i.InvoiceId = il.InvoiceId
INNER JOIN Track t
    ON il.TrackId = t.TrackId
INNER JOIN Genre g
    ON t.GenreId = g.GenreId
WHERE i.BillingCountry = 'USA'
  AND i.InvoiceDate BETWEEN '2021-01-01' AND '2021-12-31'
GROUP BY g.GenreId, g.Name
ORDER BY GenreSales DESC;

SELECT
    i.BillingCountry AS Country,
    SUM(il.UnitPrice * il.Quantity) AS TotalSales
FROM Invoice i
INNER JOIN InvoiceLine il
    ON i.InvoiceId = il.InvoiceId
WHERE i.BillingCountry = 'USA'
  AND i.InvoiceDate BETWEEN '2021-01-01' AND '2021-12-31'
GROUP BY i.BillingCountry;

SELECT
    c.FirstName AS CustomerFirstName,
    c.LastName AS CustomerLastName,
    SUM(il.UnitPrice * il.Quantity) AS TotalSales
FROM Customer c
INNER JOIN Invoice i
    ON c.CustomerId = i.CustomerId
INNER JOIN InvoiceLine il
    ON i.InvoiceId = il.InvoiceId
WHERE i.BillingCountry = 'USA'
  AND i.InvoiceDate BETWEEN '2021-01-01' AND '2021-12-31'
GROUP BY c.CustomerId, c.FirstName, c.LastName
ORDER BY TotalSales DESC;

SELECT
    t.TrackId AS SKU,
    t.Name AS ProductName,
    SUM(il.UnitPrice * il.Quantity) AS TotalRevenue
FROM Track t
INNER JOIN InvoiceLine il
    ON t.TrackId = il.TrackId
GROUP BY t.TrackId, t.Name
ORDER BY TotalRevenue DESC;

SELECT
    g.GenreId AS CategoryId,
    g.Name AS CategoryName,
    SUM(il.UnitPrice * il.Quantity) AS TotalRevenue
FROM Genre g
INNER JOIN Track t
    ON g.GenreId = t.GenreId
INNER JOIN InvoiceLine il
    ON t.TrackId = il.TrackId
GROUP BY g.GenreId, g.Name
ORDER BY TotalRevenue DESC;

SELECT
    i.BillingCountry AS Country,
    c.CustomerId,
    c.FirstName AS CustomerFirstName,
    c.LastName AS CustomerLastName,
    t.TrackId AS ProductSKU,
    t.Name AS ProductName,
    g.GenreId AS CategoryId,
    g.Name AS CategoryName,
    SUM(il.UnitPrice * il.Quantity) AS Revenue
FROM Customer c
INNER JOIN Invoice i
    ON c.CustomerId = i.CustomerId
INNER JOIN InvoiceLine il
    ON i.InvoiceId = il.InvoiceId
INNER JOIN Track t
    ON il.TrackId = t.TrackId
INNER JOIN Genre g
    ON t.GenreId = g.GenreId
WHERE i.BillingCountry = 'USA'          -- Filter by region
  AND i.InvoiceDate BETWEEN '2021-01-01' AND '2021-12-31'  -- Filter by date range
GROUP BY
    i.BillingCountry,
    c.CustomerId,
    c.FirstName,
    c.LastName,
    t.TrackId,
    t.Name,
    g.GenreId,
    g.Name
ORDER BY Revenue DESC;

SELECT
    i.BillingCountry AS Country,
    c.CustomerId,
    c.FirstName AS CustomerFirstName,
    c.LastName AS CustomerLastName,
    t.TrackId AS ProductSKU,
    t.Name AS ProductName,
    g.GenreId AS CategoryId,
    g.Name AS CategoryName,
    SUM(il.UnitPrice * il.Quantity) AS Revenue
FROM Customer c
INNER JOIN Invoice i
    ON c.CustomerId = i.CustomerId
INNER JOIN InvoiceLine il
    ON i.InvoiceId = il.InvoiceId
INNER JOIN Track t
    ON il.TrackId = t.TrackId
INNER JOIN Genre g
    ON t.GenreId = g.GenreId
WHERE i.BillingCountry = 'USA'
  AND i.InvoiceDate BETWEEN '2021-01-01' AND '2021-12-31'
GROUP BY
    i.BillingCountry,
    c.CustomerId,
    c.FirstName,
    c.LastName,
    t.TrackId,
    t.Name,
    g.GenreId,
    g.Name
ORDER BY Revenue DESC;

SELECT
    i.BillingCountry AS Country,
    c.CustomerId,
    c.FirstName AS CustomerFirstName,
    c.LastName AS CustomerLastName,
    t.TrackId AS ProductSKU,
    t.Name AS ProductName,
    g.GenreId AS CategoryId,
    g.Name AS CategoryName,
    SUM(il.UnitPrice * il.Quantity) AS Revenue
FROM Customer c
INNER JOIN Invoice i
    ON c.CustomerId = i.CustomerId
INNER JOIN InvoiceLine il
    ON i.InvoiceId = il.InvoiceId
INNER JOIN Track t
    ON il.TrackId = t.TrackId
INNER JOIN Genre g
    ON t.GenreId = g.GenreId
WHERE i.BillingCountry = 'USA'
  AND i.InvoiceDate BETWEEN '2010-01-01' AND '2010-12-31'
GROUP BY
    t.TrackId,
    t.Name
ORDER BY Revenue DESC
INTO OUTFILE '/tmp/chinook_top_products.csv'
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\3';

SELECT
    t.TrackId AS ProductSKU,
    t.Name AS ProductName,
    SUM(il.UnitPrice * il.Quantity) AS Revenue
FROM Track t
INNER JOIN InvoiceLine il
    ON t.TrackId = il.TrackId
GROUP BY t.TrackId, t.Name
ORDER BY Revenue DESC
LIMIT 3;

SELECT
    t.TrackId AS ProductSKU,
    t.Name AS ProductName,
    SUM(il.UnitPrice * il.Quantity) AS Revenue,
    ROUND(
        SUM(il.UnitPrice * il.Quantity) / total.TotalRevenue * 100, 2
    ) AS RevenuePercentage
FROM Track t
INNER JOIN InvoiceLine il
    ON t.TrackId = il.TrackId
CROSS JOIN (
    SELECT SUM(il.UnitPrice * il.Quantity) AS TotalRevenue
    FROM InvoiceLine il
) AS total
GROUP BY t.TrackId, t.Name
ORDER BY Revenue DESC
LIMIT 3;

SELECT
    t.TrackId AS ProductSKU,
    t.Name AS ProductName,
    g.GenreId AS CategoryId,
    g.Name AS CategoryName,
    SUM(il.UnitPrice * il.Quantity) AS Revenue
FROM Track t
INNER JOIN InvoiceLine il
    ON t.TrackId = il.TrackId
INNER JOIN Invoice i
    ON il.InvoiceId = i.InvoiceId
INNER JOIN Genre g
    ON t.GenreId = g.GenreId
WHERE i.BillingCountry = 'USA'
  AND i.InvoiceDate BETWEEN '2021-01-01' AND '2021-12-31'
GROUP BY t.TrackId, t.Name, g.GenreId, g.Name
ORDER BY Revenue DESC
LIMIT 10;

SELECT
    i.BillingCountry AS Country,
    c.CustomerId,
    c.FirstName AS CustomerFirstName,
    c.LastName AS CustomerLastName,
    t.TrackId AS ProductSKU,
    t.Name AS ProductName,
    g.GenreId AS CategoryId,
    g.Name AS CategoryName,
    SUM(il.UnitPrice * il.Quantity) AS Revenue
FROM Customer c
INNER JOIN Invoice i
    ON c.CustomerId = i.CustomerId
INNER JOIN InvoiceLine il
    ON i.InvoiceId = il.InvoiceId
INNER JOIN Track t
    ON il.TrackId = t.TrackId
INNER JOIN Genre g
    ON t.GenreId = g.GenreId
WHERE i.BillingCountry = 'USA'
  AND i.InvoiceDate BETWEEN '2021-01-01' AND '2021-12-31'
GROUP BY
    c.CustomerId,
    t.TrackId
ORDER BY Revenue DESC
LIMIT 3;














    


