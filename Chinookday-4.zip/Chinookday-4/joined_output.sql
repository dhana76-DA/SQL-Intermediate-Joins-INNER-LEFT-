SELECT
    t.TrackId AS ProductSKU,
    t.Name AS ProductName,
    SUM(il.UnitPrice * il.Quantity) AS Revenue,
    ROUND(SUM(il.UnitPrice * il.Quantity) / total.TotalRevenue * 100, 2) AS RevenuePercentage
FROM Track t
INNER JOIN InvoiceLine il
    ON t.TrackId = il.TrackId
CROSS JOIN (
    SELECT SUM(UnitPrice * Quantity) AS TotalRevenue
    FROM InvoiceLine
) AS total
GROUP BY t.TrackId, t.Name
ORDER BY Revenue DESC
LIMIT 3
INTO OUTFILE '/tmp/joined_output.csv'
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\3';
