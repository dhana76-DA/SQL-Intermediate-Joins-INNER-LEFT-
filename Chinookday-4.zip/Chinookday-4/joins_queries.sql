-- 1. Customers who never placed any orders
SELECT
    c.CustomerId,
    c.FirstName,
    c.LastName,
    c.Email
FROM Customer c
LEFT JOIN Invoice i
    ON c.CustomerId = i.CustomerId
WHERE i.InvoiceId IS NULL;

-- 2. Total revenue per product (Track/SKU)
SELECT
    t.TrackId AS ProductSKU,
    t.Name AS ProductName,
    SUM(il.UnitPrice * il.Quantity) AS Revenue
FROM Track t
INNER JOIN InvoiceLine il
    ON t.TrackId = il.TrackId
GROUP BY t.TrackId, t.Name
ORDER BY Revenue DESC;

-- 3. Category-wise revenue (Genre)
SELECT
    g.GenreId AS CategoryId,
    g.Name AS CategoryName,
    SUM(il.UnitPrice * il.Quantity) AS TotalRevenue
FROM Genre g
INNER JOIN Track t
    ON g.GenreId = t.GenreId
INNER JOIN InvoiceLine il
    ON t.TrackId = il.TrackId
GROUP BY g.GenreId, g.Name
ORDER BY TotalRevenue DESC;

-- 4. Total revenue by country between specific dates
SELECT
    i.BillingCountry AS Country,
    SUM(il.UnitPrice * il.Quantity) AS TotalSales
FROM Invoice i
INNER JOIN InvoiceLine il
    ON i.InvoiceId = il.InvoiceId
WHERE i.BillingCountry = 'USA'
  AND i.InvoiceDate BETWEEN '2021-01-01' AND '2021-12-31'
GROUP BY i.BillingCountry;

-- 5. Top 3 products by revenue with % contribution
SELECT
    t.TrackId AS ProductSKU,
    t.Name AS ProductName,
    SUM(il.UnitPrice * il.Quantity) AS Revenue,
    ROUND(SUM(il.UnitPrice * il.Quantity) / total.TotalRevenue * 100, 2) AS RevenuePercentage
FROM Track t
INNER JOIN InvoiceLine il
    ON t.TrackId = il.TrackId
CROSS JOIN (
    SELECT SUM(UnitPrice * Quantity) AS TotalRevenue
    FROM InvoiceLine
) AS total
GROUP BY t.TrackId, t.Name
ORDER BY Revenue DESC
LIMIT 3;
